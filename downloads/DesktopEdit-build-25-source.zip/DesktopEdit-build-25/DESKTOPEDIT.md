# DesktopEdit

DesktopEdit is a modified version of Notepad++ based on tag v8.9.9.1
(commit 066c93ac06e2f8d59c5e5f442e60d8306b603163). This fork adds DesktopEdit
branding and a separate Windows settings directory and instance identity.
See [LICENSE](LICENSE) for the GNU GPL and the upstream copyright notices.

DesktopEdit uses %APPDATA%/DesktopEdit-Npp by default. About identifies its
upstream base. The upstream updater is disabled. DesktopEdit build 25 adds a
line-number toolbar toggle and a light/dark title-bar button.

## Windows development build

Run [scripts/build-desktopedit.ps1](scripts/build-desktopedit.ps1) with the
Visual Studio 2022 C++ Build Tools and Windows SDK installed. The script builds
the x64 Release solution and stages DesktopEdit.exe in PowerEditor/bin64.
The local installation path is `C:\Utils\DesktopEdit\DesktopEdit.exe`.
Keep the model XML files and runtime asset directories beside the executable.
Run [scripts/install-desktopedit.ps1](scripts/install-desktopedit.ps1) after
building to copy the full app to the local installation path.
The half-light, half-dark button beside Minimize switches both the application
and editor colors. The same command is available under **View**.

For an isolated launch, create a settings directory and pass
-multiInst -nosession -noPlugin -settingsDir=<path>. See [BUILD.md](BUILD.md)
for the upstream build instructions.
