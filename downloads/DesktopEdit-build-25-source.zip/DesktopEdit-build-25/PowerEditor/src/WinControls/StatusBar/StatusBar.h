// This file is part of Notepad++ project
// Copyright (C)2021 Don HO <don.h@free.fr>

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// at your option any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.


#pragma once

#include <windows.h>

#include <uxtheme.h>

#include <string>
#include <vector>

#include "Window.h"

class StatusBar final : public Window
{
public:
	virtual ~StatusBar();

	void init(HINSTANCE hInst, HWND hPere, int nbParts);

	bool setPartWidth(int whichPart, int width);

	void destroy() override;

	int getHeight() const override;

	bool setText(const wchar_t* str, int whichPart);
	bool setOwnerDrawText(const wchar_t* str);
	void adjustParts(int clientWidth);

	void setFontAndHeight() noexcept;

private:
	std::vector<int> _partWidthArray;
	std::vector<int> _parts;
	std::wstring _lastSetText;
	HTHEME _hTheme = nullptr;
	HFONT _hFont = nullptr;

	using Window::init;

	static LRESULT CALLBACK StatusBarSubclass(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam, UINT_PTR uIdSubclass, DWORD_PTR dwRefData);

	bool ensureTheme() noexcept;
	void closeTheme() noexcept;
	void resetFont(UINT dpi) noexcept;
	void destroyFont() noexcept;
};
